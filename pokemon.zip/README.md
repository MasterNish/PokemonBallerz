# PokemonBallerz
A spin off of a traditional Pokemon game. 
The player will be battling opponents such as basketball players while also going through a mini story.
There will be a final boss who the character has to battle and win against.
That's all!

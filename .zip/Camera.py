from pygame import *

init()
size = width, height = 400, 210
screen = display.set_mode(size)
